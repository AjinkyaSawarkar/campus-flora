import { defineConfig, loadEnv, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { fetchPlants, type Plant } from "./shared/blogger";

// Serves /api/blogger during `npm run dev` using the same code as the Vercel function.
function bloggerDev(apiKey?: string): Plugin {
  let cache: { at: number; data: Plant[] } | null = null;
  return {
    name: "blogger-dev-api",
    configureServer(server) {
      server.middlewares.use("/api/blogger", async (_req, res) => {
        res.setHeader("Content-Type", "application/json");
        if (!apiKey) {
          res.statusCode = 500;
          res.end(JSON.stringify({ message: "BLOGGER_API_KEY is not set in .env" }));
          return;
        }
        try {
          if (!cache || Date.now() - cache.at > 5 * 60_000) {
            cache = { at: Date.now(), data: await fetchPlants(apiKey) };
          }
          res.end(JSON.stringify(cache.data));
        } catch (e) {
          res.statusCode = 502;
          res.end(JSON.stringify({ message: (e as Error).message }));
        }
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return { plugins: [react(), bloggerDev(env.BLOGGER_API_KEY)] };
});
