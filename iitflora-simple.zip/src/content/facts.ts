// Facts shown by the Sprout mascot. Add, edit or remove freely.
export const FLORA_FACTS = [
  "The banyan tree grows aerial prop roots that thicken into extra trunks!",
  "Neem is widely used in India as a natural pest repellent and in traditional medicine.",
  "The campus sits at the foothills of the Seshachalam range, part of the Eastern Ghats.",
  "Fruit trees on campus feed birds, squirrels and bees.",
  "Avenue trees give shade and keep paved roads cooler on hot afternoons.",
  "Sacred groves have been protected around temples in many parts of India for centuries.",
  "Climbing plants use tendrils that curl tightly when they touch a support.",
  "Through photosynthesis, every tree on campus takes in carbon dioxide and releases oxygen.",
  "IIT Tirupati's two lakes cover about 10 acres and store rainwater for the campus.",
];
