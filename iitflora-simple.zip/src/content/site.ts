export interface Category {
  id: string;
  title: string;
  blurb: string;
  /** Blogger labels (tags) that put a post in this category. */
  tags: string[];
}

// The 9 flora categories, with the same Blogger label ("tag") each one used on the old site.
// A post belongs to a category when one of its Blogger labels contains the tag as a whole word
// (case-insensitive, plural allowed: "Creepers" matches "creeper").
export const categories: Category[] = [
  { id: "avenue-trees", title: "Avenue Trees", blurb: "Trees suitable for lining streets and avenues.", tags: ["avenue"] },
  { id: "fruit-trees", title: "Fruit Trees", blurb: "Trees that bear edible fruits.", tags: ["fruit"] },
  { id: "sacred-medicinal", title: "Sacred & Medicinal", blurb: "Trees with religious significance or medicinal properties.", tags: ["sacred"] },
  { id: "palms-specimen", title: "Palms & Specimen", blurb: "Decorative palms and unique specimen plants.", tags: ["palm"] },
  { id: "shrubs-ground-covers", title: "Shrubs & Ground Covers", blurb: "Plants that cover the ground or form short hedges.", tags: ["shrub"] },
  { id: "creepers", title: "Creepers", blurb: "Plants that grow along surfaces or climb.", tags: ["creeper"] },
  { id: "medicinal-aromatic", title: "Medicinal & Aromatic Herbs", blurb: "Herbs with medicinal properties or pleasant aromas.", tags: ["aromatic"] },
  { id: "biodiversity", title: "Biodiversity Plantation", blurb: "Plants that support and enhance biodiversity.", tags: ["biodiversity"] },
  { id: "fruit-bearing", title: "Fruit Bearing Trees", blurb: "Trees that produce fruits for consumption.", tags: ["bearing"] },
];

export const navItems = [
  { label: "Home", href: "/" },
  { label: "Flora on campus", href: "/flora" },
  { label: "Team", href: "/team" },
  { label: "Contact", href: "/contact" },
  { label: "About us", href: "/about" },
];

// Campus facts shown under the map on the front page
// (source: iittp.ac.in About Us / Permanent Campus pages, IIT Tirupati newsletter Samvid).
export const campusFacts = [
  { value: "548.3 acres", label: "Permanent campus, Merlapaka village, Yerpedu" },
  { value: "22 km", label: "from Tirupati town, on the Yerpedu–Venkatagiri road" },
  { value: "2 lakes", label: "about 10 acres, storing rainwater" },
  { value: "12,000", label: "students planned in the master plan" },
];

// ---- To be filled in later ------------------------------------------------
export interface Person { name: string; role?: string; photo?: string }

export const horticulture = {
  intro: "", // paragraph about the horticulture section
  head: { name: "", designation: "", email: "", photo: "" },
  gardeners: [] as Person[],
};

export const nisarga = { email: "" };

export const developers: Person[] = [];
