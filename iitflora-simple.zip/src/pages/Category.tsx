import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { categories } from "../content/site";
import { factLines, inCategory, sized, usePlants, type Plant } from "../lib/plants";
import Lightbox from "../components/Lightbox";
import NotFound from "./NotFound";

function PlantViewer({ plant }: { plant: Plant }) {
  const [i, setI] = useState(0);
  const n = plant.images.length;
  const go = (d: number) => setI((x) => (x + d + n) % n);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (n < 2) return;
      if (e.key === "ArrowLeft") go(-1);
      if (e.key === "ArrowRight") go(1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <div className="flex h-full w-full max-w-5xl flex-col gap-3">
      <div className="relative flex min-h-0 flex-1 items-center justify-center">
        {n > 0 ? (
          <img src={sized(plant.images[i], 1600)} alt={`${plant.title}, photo ${i + 1} of ${n}`} className="max-h-full max-w-full rounded-lg object-contain" />
        ) : (
          <p className="text-white">No photos for this plant yet.</p>
        )}
        {n > 1 && (
          <>
            <button type="button" onClick={() => go(-1)} aria-label="Previous photo" className="absolute left-0 rounded-full bg-white/90 px-4 py-3 text-xl text-forest hover:bg-white">‹</button>
            <button type="button" onClick={() => go(1)} aria-label="Next photo" className="absolute right-0 rounded-full bg-white/90 px-4 py-3 text-xl text-forest hover:bg-white">›</button>
          </>
        )}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 text-white">
        <p className="font-serif text-xl">{plant.title}{n > 1 && <span className="ml-3 text-sm opacity-80">{i + 1} / {n}</span>}</p>
        <a href={plant.url} target="_blank" rel="noopener noreferrer" className="rounded-full border border-white/60 px-4 py-1.5 text-sm hover:bg-white hover:text-forest">
          Read the original post ↗
        </a>
      </div>
    </div>
  );
}

export default function Category({ id }: { id: string }) {
  const cat = categories.find((c) => c.id === id);
  const index = categories.findIndex((c) => c.id === id);
  const { data: plants = [], isLoading, error, refetch } = usePlants();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Plant | null>(null);

  const items = useMemo(() => {
    if (!cat) return [];
    const all = inCategory(plants, cat).sort((a, b) => a.title.localeCompare(b.title));
    const s = q.trim().toLowerCase();
    return s ? all.filter((p) => p.title.toLowerCase().includes(s)) : all;
  }, [plants, cat, q]);

  if (!cat) return <NotFound />;

  return (
    <>
      <Link href="/flora" className="text-sm text-moss hover:underline">← All categories</Link>
      <header className="mb-8 mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm tracking-widest text-clay">{String(index + 1).padStart(2, "0")}</p>
          <h1 className="text-4xl font-semibold text-forest sm:text-5xl">{cat.title}</h1>
          <p className="mt-2 max-w-xl text-ink/80">{cat.blurb}</p>
        </div>
        <label className="text-sm">
          <span className="sr-only">Search in this category</span>
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={`Search ${cat.title.toLowerCase()}…`}
            className="w-64 rounded-full border border-forest/30 bg-white px-4 py-2 outline-none focus:border-clay"
          />
        </label>
      </header>

      {isLoading && <p>Loading plants…</p>}
      {error && (
        <p role="alert" className="text-clay">
          Could not load plants. <button type="button" className="underline" onClick={() => refetch()}>Try again</button>
        </p>
      )}
      {!isLoading && !error && items.length === 0 && (
        <p>{q ? `No plant matches “${q}”.` : "No plants have been posted in this category yet."}</p>
      )}

      <ul className="grid grid-cols-1 gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p, i) => (
          <li key={p.id} id={`plant-${p.id}`} className="scroll-mt-6">
            <button type="button" onClick={() => setOpen(p)} className="group block w-full text-left" aria-label={`View photos of ${p.title}`}>
              <div className="aspect-[4/5] overflow-hidden rounded-sm bg-forest/10">
                {p.images[0] ? (
                  <img src={sized(p.images[0], 640)} alt={p.title} loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                ) : (
                  <div className="flex h-full items-center justify-center text-5xl" aria-hidden="true">🌿</div>
                )}
              </div>
              <p className="mt-4 text-sm tracking-widest text-clay">{String(i + 1).padStart(2, "0")}</p>
              <h2 className="text-2xl font-semibold text-forest group-hover:underline">{p.title}</h2>
            </button>
            <ul className="mt-2 space-y-1 text-sm text-ink/80">
              {factLines(p).map((l) => <li key={l} className="before:mr-2 before:text-clay before:content-['–']">{l}</li>)}
            </ul>
            <p className="mt-2 text-xs uppercase tracking-wider text-moss">{p.images.length} {p.images.length === 1 ? "photo" : "photos"}</p>
          </li>
        ))}
      </ul>

      {items.length > 8 && (
        <nav aria-label="Index of plants" className="mt-16 border-t border-forest/20 pt-6">
          <h2 className="mb-3 text-lg text-forest">Index</h2>
          <ol className="columns-2 gap-8 text-sm sm:columns-3 lg:columns-4">
            {items.map((p, i) => (
              <li key={p.id} className="mb-1">
                <a href={`#plant-${p.id}`} className="hover:underline"><span className="mr-2 text-clay">{String(i + 1).padStart(2, "0")}</span>{p.title}</a>
              </li>
            ))}
          </ol>
        </nav>
      )}

      <Lightbox open={!!open} onClose={() => setOpen(null)} label={open ? `${open.title} photos` : "Plant photos"}>
        {open && <PlantViewer key={open.id} plant={open} />}
      </Lightbox>
    </>
  );
}
