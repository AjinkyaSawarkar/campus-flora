import { horticulture } from "../content/site";
import Pending from "../components/Pending";

export default function About() {
  const { intro, gardeners } = horticulture;
  return (
    <>
      <h1 className="mb-8 text-4xl font-semibold text-forest sm:text-5xl">About us</h1>

      <section className="mb-12 max-w-3xl">
        <h2 className="mb-3 text-2xl font-semibold text-forest">The horticulture section</h2>
        {intro ? <p className="leading-relaxed">{intro}</p> : <Pending what="The horticulture section description" />}
      </section>

      <section>
        <h2 className="mb-4 text-2xl font-semibold text-forest">Our gardeners</h2>
        {gardeners.length === 0 ? (
          <Pending what="The list of gardeners" />
        ) : (
          <ul className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {gardeners.map((g) => (
              <li key={g.name}>
                {g.photo && <img src={g.photo} alt={g.name} className="mb-2 aspect-square w-full rounded-sm object-cover" loading="lazy" />}
                <p className="font-semibold text-forest">{g.name}</p>
                {g.role && <p className="text-sm text-ink/75">{g.role}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
