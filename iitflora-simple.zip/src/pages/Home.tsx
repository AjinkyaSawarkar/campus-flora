import { useState } from "react";
import { Link } from "wouter";
import { campusFacts, navItems } from "../content/site";
import Lightbox from "../components/Lightbox";

export default function Home() {
  const [mapOpen, setMapOpen] = useState(false);

  return (
    <div className="relative isolate min-h-screen overflow-hidden text-white">
      <div className="absolute inset-0 -z-20 bg-cover bg-center" style={{ backgroundImage: "url(/bg.webp)" }} aria-hidden="true" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-forest/95 via-forest/70 to-forest/35" aria-hidden="true" />

      <div className="mx-auto grid min-h-screen max-w-7xl items-center gap-10 px-4 py-10 sm:px-8 lg:grid-cols-[19rem_1fr]">
        <div>
          <div className="mb-6 flex items-center gap-3">
            <span className="rounded-xl bg-white p-2"><img src="/iitt-logo.svg" alt="IIT Tirupati" className="h-12 w-auto" /></span>
            <span className="rounded-full bg-white p-1"><img src="/nisarga.webp" alt="Nisarga club" className="h-14 w-14 rounded-full" /></span>
          </div>
          <h1 className="font-serif text-4xl font-semibold leading-tight sm:text-5xl">Campus Flora</h1>
          <p className="mb-8 mt-2 text-white/85">IIT Tirupati · a Nisarga initiative</p>

          <nav aria-label="Main" className="flex flex-col gap-3">
            {navItems.map((n, i) => (
              <Link
                key={n.href}
                href={n.href}
                className="flex items-center justify-between rounded-full border border-white/50 bg-white/10 px-6 py-3 text-lg font-medium backdrop-blur-sm transition-colors hover:bg-white hover:text-forest focus-visible:bg-white focus-visible:text-forest"
              >
                <span>{n.label}</span>
                <span className="text-sm opacity-70" aria-hidden="true">{String(i + 1).padStart(2, "0")}</span>
              </Link>
            ))}
          </nav>
        </div>

        <section aria-labelledby="map-heading" className="rounded-2xl bg-cream/95 p-3 text-ink shadow-2xl sm:p-4">
          <h2 id="map-heading" className="sr-only">Campus map</h2>
          <button type="button" onClick={() => setMapOpen(true)} className="block w-full overflow-hidden rounded-xl" aria-label="Enlarge the campus master plan">
            <img src="/map.webp" alt="Master plan of the IIT Tirupati campus with a legend of buildings and facilities" className="w-full" />
          </button>
          <p className="mt-2 text-center text-xs text-ink/70">Master plan, IIT Tirupati · tap the map to enlarge</p>

          <dl className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {campusFacts.map((f) => (
              <div key={f.value} className="rounded-xl bg-white p-3">
                <dt className="font-serif text-xl font-semibold text-forest">{f.value}</dt>
                <dd className="text-xs leading-snug text-ink/75">{f.label}</dd>
              </div>
            ))}
          </dl>
        </section>
      </div>

      <Lightbox open={mapOpen} onClose={() => setMapOpen(false)} label="Campus master plan">
        <img src="/map.webp" alt="Master plan of the IIT Tirupati campus" className="max-h-full max-w-full rounded-lg bg-white object-contain" />
      </Lightbox>
    </div>
  );
}
