import { developers, horticulture } from "../content/site";
import Pending from "../components/Pending";

export default function Team() {
  const { head } = horticulture;
  return (
    <>
      <h1 className="mb-8 text-4xl font-semibold text-forest sm:text-5xl">Team</h1>

      <section className="mb-12">
        <h2 className="mb-4 text-2xl font-semibold text-forest">Horticulture head</h2>
        {head.name ? (
          <div className="flex items-center gap-5">
            {head.photo && <img src={head.photo} alt={head.name} className="h-32 w-32 rounded-sm object-cover" />}
            <div>
              <p className="text-xl font-semibold">{head.name}</p>
              <p className="text-ink/75">{head.designation}</p>
            </div>
          </div>
        ) : (
          <Pending what="The horticulture head's details" />
        )}
      </section>

      <section>
        <h2 className="mb-4 text-2xl font-semibold text-forest">Website team</h2>
        {developers.length === 0 ? (
          <Pending what="The website team" />
        ) : (
          <ul className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {developers.map((d) => (
              <li key={d.name}>
                {d.photo && <img src={d.photo} alt={d.name} className="mb-2 aspect-square w-full rounded-sm object-cover" loading="lazy" />}
                <p className="font-semibold text-forest">{d.name}</p>
                {d.role && <p className="text-sm text-ink/75">{d.role}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
