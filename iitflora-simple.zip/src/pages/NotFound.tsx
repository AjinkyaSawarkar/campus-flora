import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="py-16 text-center">
      <h1 className="mb-3 text-4xl font-semibold text-forest">Page not found</h1>
      <p className="mb-6">This path has no plant growing on it.</p>
      <Link href="/" className="rounded-full bg-forest px-5 py-2 text-white hover:bg-moss">Back to home</Link>
    </div>
  );
}
