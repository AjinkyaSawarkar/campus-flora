import { horticulture, nisarga } from "../content/site";

function Card({ title, email }: { title: string; email: string }) {
  return (
    <div className="rounded-xl bg-white p-6 shadow-sm ring-1 ring-forest/10">
      <h2 className="mb-2 text-xl font-semibold text-forest">{title}</h2>
      {email ? (
        <a href={`mailto:${email}`} className="break-all text-clay underline">{email}</a>
      ) : (
        <p className="text-sm text-ink/70">Email address will be added soon.</p>
      )}
    </div>
  );
}

export default function Contact() {
  return (
    <>
      <h1 className="mb-8 text-4xl font-semibold text-forest sm:text-5xl">Contact</h1>
      <div className="grid gap-6 sm:grid-cols-2">
        <Card title="Nisarga club" email={nisarga.email} />
        <Card title="Horticulture head" email={horticulture.head.email} />
      </div>
    </>
  );
}
