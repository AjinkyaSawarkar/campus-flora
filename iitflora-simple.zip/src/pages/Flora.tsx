import { Link } from "wouter";
import { categories } from "../content/site";
import { inCategory, sized, usePlants } from "../lib/plants";

export default function Flora() {
  const { data: plants = [], isLoading, error } = usePlants();

  return (
    <>
      <header className="mb-10 max-w-2xl">
        <h1 className="text-4xl font-semibold text-forest sm:text-5xl">Flora on campus</h1>
        <p className="mt-3 text-ink/80">{categories.length} categories of plants grow across the IIT Tirupati campus. Pick one to browse its photographs.</p>
        {error && <p role="alert" className="mt-3 text-clay">Plant records could not be loaded right now; categories still work.</p>}
      </header>

      <ul className="grid grid-cols-1 gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c, i) => {
          const items = inCategory(plants, c);
          const cover = items.find((p) => p.images.length)?.images[0];
          return (
            <li key={c.id}>
              <Link href={`/flora/${c.id}`} className="group block">
                <div className="aspect-[4/5] overflow-hidden rounded-sm bg-forest/10">
                  {cover ? (
                    <img src={sized(cover, 640)} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-5xl" aria-hidden="true">{isLoading ? "…" : "🌿"}</div>
                  )}
                </div>
                <p className="mt-4 text-sm tracking-widest text-clay">{String(i + 1).padStart(2, "0")}</p>
                <h2 className="text-2xl font-semibold text-forest group-hover:underline">{c.title}</h2>
                <p className="mt-1 text-sm text-ink/75">{c.blurb}</p>
                <p className="mt-2 text-xs font-medium uppercase tracking-wider text-moss">{isLoading ? "Loading…" : `${items.length} plants`}</p>
              </Link>
            </li>
          );
        })}
      </ul>
    </>
  );
}
