import { Route, Switch } from "wouter";
import Home from "./pages/Home";
import Flora from "./pages/Flora";
import Category from "./pages/Category";
import About from "./pages/About";
import Team from "./pages/Team";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import Shell from "./components/Shell";
import Sprout from "./components/Sprout";

export default function App() {
  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/flora"><Shell><Flora /></Shell></Route>
        <Route path="/flora/:id">{(p) => <Shell><Category id={p.id} /></Shell>}</Route>
        <Route path="/team"><Shell><Team /></Shell></Route>
        <Route path="/contact"><Shell><Contact /></Shell></Route>
        <Route path="/about"><Shell><About /></Shell></Route>
        <Route><Shell><NotFound /></Shell></Route>
      </Switch>
      <Sprout />
    </>
  );
}
