import { useQuery } from "@tanstack/react-query";
import type { Plant } from "../../shared/blogger";
import type { Category } from "../content/site";

export type { Plant };

export function usePlants() {
  return useQuery<Plant[]>({
    queryKey: ["plants"],
    queryFn: async () => {
      const res = await fetch("/api/blogger");
      if (!res.ok) throw new Error("Could not load the plant records.");
      return res.json();
    },
  });
}

const escapeRe = (t: string) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** True if a Blogger label contains the tag as a whole word (plural allowed), case-insensitive. */
export function labelHasTag(label: string, tag: string): boolean {
  return new RegExp(`\\b${escapeRe(tag)}(?:s|es)?\\b`, "i").test(label);
}

export function inCategory(plants: Plant[], cat: Category): Plant[] {
  return plants.filter((p) => p.labels.some((l) => cat.tags.some((t) => labelHasTag(l, t))));
}

/** Blogger-hosted images accept a size segment: use small ones for tiles, large ones for the viewer. */
export const sized = (url: string, px: number) => url.replace("/s1600/", `/s${px}/`);

/** First few non-empty lines of a post, shown as short facts under the picture. */
export function factLines(p: Plant, max = 3): string[] {
  return p.text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 2 && l.toLowerCase() !== p.title.trim().toLowerCase())
    .slice(0, max)
    .map((l) => (l.length > 120 ? l.slice(0, 117) + "…" : l));
}
