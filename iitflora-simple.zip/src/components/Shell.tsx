import { useEffect, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { navItems } from "../content/site";

export default function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  useEffect(() => window.scrollTo(0, 0), [location]);

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-forest/15 bg-cream/95">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-4 sm:px-6">
          <Link href="/" className="flex items-center gap-3">
            <img src="/nisarga.webp" alt="" className="h-10 w-10 rounded-full" />
            <span className="font-serif text-xl font-semibold text-forest">Campus Flora</span>
          </Link>
          <nav aria-label="Main" className="flex flex-wrap gap-x-5 gap-y-1 text-sm font-medium">
            {navItems.map((n) => {
              const active = n.href === "/" ? location === "/" : location.startsWith(n.href);
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  aria-current={active ? "page" : undefined}
                  className={`border-b-2 py-1 transition-colors ${
                    active ? "border-clay text-forest" : "border-transparent text-ink/75 hover:text-forest"
                  }`}
                >
                  {n.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10 sm:px-6">{children}</main>
      <footer className="border-t border-forest/15 py-6 text-center text-sm text-ink/70">
        Nisarga · Indian Institute of Technology Tirupati
      </footer>
    </div>
  );
}
