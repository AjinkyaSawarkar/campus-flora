# Campus Flora (simple rebuild)

1. `npm install`
2. Copy `.env.example` to `.env` and put a NEW Blogger API key in `BLOGGER_API_KEY` (restrict it to the Blogger API).
3. `npm run dev` then open http://localhost:5173
4. `npm run typecheck` and `npm run build` before deploying to Vercel (add `BLOGGER_API_KEY` in the Vercel project settings).

Edit text and data here:
- `src/content/site.ts`: the 9 categories (and their Blogger label tags), campus facts, About / Team / Contact details
- `src/content/facts.ts`: facts shown by Sprout
